# Заголовок
print("Калькулятор Уравнений V2.0")

# Основная функция для решения уравнений

def solve_equation(eq_type):
    if eq_type == 1:
        # Решение линейного уравнения ax + b = 0
        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))

        if a == 0:
            if b == 0:
                print("Уравнение имеет бесконечное множество корней")
            else:
                print("Уравнение не имеет корней")
        else:
            x = -b/a
            print("Корень уравнения: x =", x)

    elif eq_type == 2:
        # Решение квадратного уравнения ax^2 + bx + c = 0
        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))
        c = float(input("Введите значение c: "))

        D = b**2 - 4*a*c

        if D > 0:
            x1 = (-b + D**0.5) / (2*a)
            x2 = (-b - D**0.5) / (2*a)
            print("Корни уравнения: x1 =", x1, "и x2 =", x2)
        elif D == 0:
            x = -b / (2*a)
            print("Уравнение имеет один корень: x =", x)
        else:
            print("Уравнение не имеет действительных корней")

    elif eq_type == 3:
        # Решение кубического уравнения ax^3 + bx^2 + cx + d = 0
        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))
        c = float(input("Введите значение c: "))
        d = float(input("Введите значение d:"))

        # Решение кубического уравнения
        q = (3*a*c - b**2) / (9*a**2)
        r = (9*a*b*c - 27*a**2*d - 2*b**3) / (54*a**3)
        D = q**3 + r**2

        if q == 0 and r == 0:
            x1 = -b / (3*a)
            print("Уравнение имеет один тройной корень: x =", x1)
        elif D > 0:
            s = ((r + D**0.5)/2)**(1/3) if r + D**0.5 > 0 else -((-r + D**0.5)/2)**(1/3)
            t = ((r - D**0.5)/2)**(1/3) if r - D**0.5 > 0 else -((-r - D**0.5)/2)**(1/3)
            x1 = s + t - b/(3*a)
            print("Корень уравнения: x =", x1)
        elif D == 0:
            x1 = 2*(r)**(1/3) - b/(3*a)
            x2 = -(r)**(1/3) - b/(3*a)
            print("Уравнение имеет двойной корень: x1 =", x1, "и x2 =", x2)
        else:
            rho = (-D)**0.5
            theta = math.acos(r/rho)
            x1 = 2*(rho**(1/3))*math.cos(theta/3) - b/(3*a)
            x2 = 2*(rho**(1/3))*math.cos((theta + 2*math.pi)/3) - b/(3*a)
            x3 = 2*(rho**(1/3))*math.cos((theta - 2*math.pi)/3) - b/(3*a)
            print("Корни уравнения: x1 =", x1, "x2 =", x2, "и x3 =", x3)

    elif eq_type == 4:
        # Решение рационального уравнения (при подходящих условиях)
        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))
        c = float(input("Введите значение c: "))

        if a == 0:
            if b == 0 and c != 0:
                print("Уравнение не имеет корней")
            elif b == 0 and c == 0:
                print("Уравнение имеет бесконечное множество корней")
            else:
                x = -c / b
                print("Корень уравнения: x =", x)
        else:
            discriminant = b**2 - 4*a*c
            if discriminant > 0:
                x1 = (-b + discriminant**0.5) / (2*a)
                x2 = (-b - discriminant**0.5) / (2*a)
                print("Корни уравнения: x1 =", x1, "и x2 =", x2)
            elif discriminant == 0:
                x = -b / (2*a)
                print("Уравнение имеет один корень: x =", x)
            else:
                print("Уравнение не имеет действительных корней")

    elif eq_type == 5:
        # Решение иррационального уравнения
        import math

        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))
        c = float(input("Введите значение c: "))

        discriminant = b**2 - 4*a*c

        if discriminant >= 0:
            x1 = (-b + discriminant**0.5) / (2*a)
            x2 = (-b - discriminant**0.5) / (2*a)
            print("Корни уравнения: x1 =", x1, "и x2 =", x2)
        else:
            real_part = -b / (2*a)
            imaginary_part = (-discriminant)**0.5 / (2*a)
            x1 = complex(real_part, imaginary_part)
            x2 = complex(real_part, -imaginary_part)
            print("Комплексные корни уравнения: x1 =", x1, "и x2 =", x2)
     
    elif eq_type == 6:
        # Решение биквадратного уравнения ax^4 + bx^2 + c = 0
        a = float(input("Введите значение a: "))
        b = float(input("Введите значение b: "))
        c = float(input("Введите значение c: "))

        # Решение биквадратного уравнения
        D = b**2 - 4*a*c

        if D > 0:
            x1 = ((-b + D**0.5) / (2*a))**0.5
            x2 = ((-b - D**0.5) / (2*a))**0.5
            print("Корни уравнения: x1 =", x1, "и x2 =", x2)
        elif D == 0:
            x = (-b / (2*a))**0.5
            print("Уравнение имеет один корень: x =", x)
        else:
            print("Уравнение не имеет действительных корней")

# Возвращаемся в основное меню
    main_menu()

# Основное меню
def main_menu():
    print("\nВыберите тип уравнения:")
    print("1. Линейное уравнение: ax + b = 0")
    print("2. Квадратное уравнение: ax^2 + bx + c = 0")
    print("3. Кубическое уравнение ax^3 + bx^2 + cx + d = 0")
    print("4. Рациональное уравнение ax + b = c")
    print("5. Иррациональное уравнение ax^2 + bx + c = 0")
    print("6. Биквадратное уравнение ax^4 + bx^2 + c = 0")
    print("0. Выход")

    choice = int(input("Введите число: "))

    if choice == 0:
        print("Программа завершена. До свидания!")
    elif choice == 1 or choice == 2:
        solve_equation(choice)
    else:
        print("Некорректный выбор. Пожалуйста, попробуйте снова.")
        main_menu()

# Запуск программы
main_menu()